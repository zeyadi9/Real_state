<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\OvertimeController;
use App\Http\Controllers\view_Overtime;

Route::get('/', function () {
    return view('welcome');
})->name('home');

Route::get('login', [LoginController::class, 'login'])->name('login');
Route::post('login', [LoginController::class, 'login_post'])->name('login_post');

Route::get('register', [LoginController::class, 'register'])->name('register');
Route::post('register', [LoginController::class, 'register_post'])->name('register_post');

Route::post('logout', [LoginController::class, 'logout'])->name('logout');

// يوزر عادي فقط
Route::middleware(['auth'])->group(function(){
    Route::get('/overtime', [OvertimeController::class, 'overtime'])->name('Overtime');
    Route::post('/overtime_post', [OvertimeController::class, 'overtime_post'])->name('overtime_post');
    Route::get('/view_overtime', [view_Overtime::class, 'view_Overtime'])->name('view_Overtime');
});

// ادمن فقط
Route::middleware(['auth', 'admin'])->group(function(){
    Route::post('/overtime/{id}/accept', [OvertimeController::class, 'accept'])->name('overtime.accept');
    Route::post('/overtime/{id}/refuse', [OvertimeController::class, 'refuse'])->name('overtime.refuse');
});


Route::get('logout', [LoginController::class, 'logout'])->name('logout');
Route::post('logout', [LoginController::class, 'logout']);



use App\Http\Controllers\LeavePermissionController;

Route::middleware(['auth'])->group(function () {

    // Leave
    Route::get('/leave', [LeavePermissionController::class, 'leave_index'])->name('leave');
    Route::post('/leave', [LeavePermissionController::class, 'leave_post'])->name('leave_post');
    Route::get('/view_leave', [LeavePermissionController::class, 'view_leave'])->name('view_leave');

    // Permission
    Route::get('/permission', [LeavePermissionController::class, 'permission_index'])->name('permission');
    Route::post('/permission', [LeavePermissionController::class, 'permission_post'])->name('permission_post');
    Route::get('/view_permission', [LeavePermissionController::class, 'view_permission'])->name('view_permission');
});

Route::middleware(['auth', 'admin'])->group(function () {
    // Leave Admin
    Route::post('/leave/{id}/accept', [LeavePermissionController::class, 'leave_accept'])->name('leave.accept');
    Route::post('/leave/{id}/refuse', [LeavePermissionController::class, 'leave_refuse'])->name('leave.refuse');

    // Permission Admin
    Route::post('/permission/{id}/accept', [LeavePermissionController::class, 'permission_accept'])->name('permission.accept');
    Route::post('/permission/{id}/refuse', [LeavePermissionController::class, 'permission_refuse'])->name('permission.refuse');
});


// routes/web.php
Route::get('/overtime/export', [OvertimeController::class, 'export'])
    ->name('overtime.export')
    ->middleware('auth');


    Route::get('/leaves/export', [LeavePermissionController::class, 'export_lev'])->name('leave.export')->middleware('auth');
Route::get('/permissions/export', [LeavePermissionController::class, 'export_per'])->name('permission.export')->middleware('auth');
