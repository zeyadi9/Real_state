@extends('layout')
@section('title', 'View Permissions')
@section('content')

<div class="relative overflow-x-auto bg-neutral-primary-soft shadow-xs rounded-base border border-default mt-20">
    <table class="w-full text-sm text-left rtl:text-right text-body">
        <thead class="bg-neutral-secondary-soft border-b border-default">
            <tr>
                <th class="px-6 py-3 font-medium">N</th>
                <th class="px-6 py-3 font-medium">Employee Name</th>
                <th class="px-6 py-3 font-medium">Date</th>
                <th class="px-6 py-3 font-medium">Day</th>
                <th class="px-6 py-3 font-medium">Reason</th>
                <th class="px-6 py-3 font-medium">From</th>
                <th class="px-6 py-3 font-medium">To</th>
                <th class="px-6 py-3 font-medium">Duration</th>
                <th class="px-6 py-3 font-medium">Status</th>
                @if(Auth::user()->role === 'admin')
                <th class="px-6 py-3 font-medium">Actions</th>
                @endif
                <th class="px-6 py-3 font-medium">Created At</th>
            </tr>
        </thead>
        <tbody>
            @forelse($permissions as $index => $item)
            <tr class="odd:bg-neutral-primary even:bg-neutral-secondary-soft border-b border-default">
                <td class="px-6 py-4">{{ $index + 1 }}</td>
                <td class="px-6 py-4 font-medium text-heading">{{ $item->name }}</td>
                <td class="px-6 py-4">{{ \Carbon\Carbon::parse($item->date)->format('d M Y') }}</td>
                <td class="px-6 py-4">{{ $item->day }}</td>
                <td class="px-6 py-4">{{ $item->reason }}</td>
                <td class="px-6 py-4">
                    {{ $item->from 
                        ? date('h:i', strtotime($item->from)) . (date('A', strtotime($item->from)) == 'AM' ? ' ص' : ' م') 
                        : '-' 
                    }}
                </td>

                <td class="px-6 py-4">
                    {{ $item->to 
                        ? date('h:i', strtotime($item->to)) . (date('A', strtotime($item->to)) == 'AM' ? ' ص' : ' م') 
                        : '-' 
                    }}
                </td>
                <td class="px-6 py-4">
                    @php
                        $from = \Carbon\Carbon::parse($item->from);
                        $to   = \Carbon\Carbon::parse($item->to);
                        $diff = $from->diffInMinutes($to);
                        $h    = intdiv($diff, 60);
                        $m    = $diff % 60;
                    @endphp
                    <span class="bg-purple-100 text-purple-700 text-xs font-medium px-2.5 py-1 rounded-full">
                        {{ $h }}h {{ $m }}m
                    </span>
                    @if($item->alarm)
                        <span class="bg-red-100 text-red-700 text-xs font-medium px-2.5 py-1 rounded-full ms-1">
                            ⚠️ Exceeded 3h
                        </span>
                    @endif
                </td>
                <td class="px-6 py-4">
                    @if($item->status === 'accepted')
                        <span class="bg-green-100 text-green-700 text-xs font-medium px-2.5 py-1 rounded-full">Accepted</span>
                    @elseif($item->status === 'refused')
                        <span class="bg-red-100 text-red-700 text-xs font-medium px-2.5 py-1 rounded-full">Refused</span>
                    @else
                        <span class="bg-yellow-100 text-yellow-700 text-xs font-medium px-2.5 py-1 rounded-full">Pending</span>
                    @endif
                </td>
                @if(Auth::user()->role === 'admin')
                <td class="px-6 py-4">
                    @if($item->status === 'pending')
                    <div class="flex gap-2">
                        <form action="{{ route('permission.accept', $item->id) }}" method="POST">
                            @csrf
                            <button type="submit" class="text-white bg-green-600 hover:bg-green-700 text-sm px-3 py-1.5 rounded">Accept</button>
                        </form>
                        <button type="button"
                        onclick="document.getElementById('permRefuseModal{{ $item->id }}').classList.remove('hidden')"
                        class="text-white bg-red-600 hover:bg-red-700 text-sm px-3 py-1.5 rounded">
                        Refuse
                            </button>
                        </div>
                        <div id="permRefuseModal{{ $item->id }}" class="hidden fixed inset-0 z-50 items-center justify-center bg-black bg-opacity-50">
                            <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
                                <h5 class="text-lg font-semibold mb-4">Reason for Refusal</h5>
                                <form action="{{ route('permission.refuse', $item->id) }}" method="POST">
                                    @csrf
                                    <textarea name="refuse_reason" rows="4" required placeholder="Enter reason..."
                                    class="w-full border border-gray-300 rounded-lg p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-red-400 mb-4"></textarea>
                                    <div class="flex justify-end gap-2">
                                        <button type="button"
                                            onclick="document.getElementById('permRefuseModal{{ $item->id }}').classList.add('hidden')"
                                            class="px-4 py-2 text-sm bg-gray-200 hover:bg-gray-300 rounded">Cancel</button>
                                        <button type="submit" class="px-4 py-2 text-sm text-white bg-red-600 hover:bg-red-700 rounded">Confirm Refuse</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        @else
                        <span class="text-gray-400 text-xs">Done</span>
                        @endif
                    </td>
                    <td class="px-6 py-4">{{ $item->created_at->toDateString() }}</td>
                @endif
            </tr>
            @if($item->status === 'refused' && $item->refuse_reason)
            <tr class="bg-red-50 border-b border-default">
                <td colspan="{{ Auth::user()->role === 'admin' ? 10 : 9 }}" class="px-6 py-2">
                    <span class="text-red-600 text-xs font-medium">Refuse Reason: </span>
                    <span class="text-red-500 text-xs">{{ $item->refuse_reason }}</span>
                </td>
            </tr>
            @endif
            @empty
            <tr>
                <td colspan="10" class="px-6 py-6 text-center text-body">No permission records found.</td>
            </tr>
            @endforelse
        </tbody>

        <tfoot>
            <tr class="bg-neutral-secondary-soft font-semibold">
                <td colspan="2" class="px-6 py-4 text-heading">
                    Total This Period
                    <span class="text-xs font-normal text-body block">
                        {{ $periodStart->format('d M Y') }} → {{ $periodEnd->format('d M Y') }}
                    </span>
                </td>
                <td colspan="2" class="px-6 py-4 text-heading">
                    {{ $permissions->where('status', 'accepted')->count() }} permissions
                </td>
                <td colspan="6"></td>
            </tr>

            <tr class="bg-blue-50 font-semibold">
                <td colspan="2" class="px-6 py-4 text-heading">Total Hours (From → To)</td>
                <td colspan="{{ Auth::user()->role === 'admin' ? 8 : 7 }}" class="px-6 py-4 text-heading">
                    @php
                        $totalMinutes = $permissions->where('status', 'accepted')->sum(function($item) {
                            $from = \Carbon\Carbon::parse($item->from);
                            $to   = \Carbon\Carbon::parse($item->to);
                            return $from->diffInMinutes($to);
                        });
                        $hours   = intdiv($totalMinutes, 60);
                        $minutes = $totalMinutes % 60;
                    @endphp
                    <span class="bg-blue-100 text-blue-700 text-xs font-medium px-2.5 py-1 rounded-full">
                        {{ $hours }}h {{ $minutes }}m
                    </span>
                </td>
            </tr>
        </tfoot>
    </table>
</div>

@if(Auth::user()->role === 'admin')
<div class="relative overflow-x-auto bg-neutral-primary-soft shadow-xs rounded-base border border-default mt-6">
    <div class="px-6 py-3 bg-neutral-secondary-soft border-b border-default">
        <h6 class="font-semibold text-heading">
            Monthly Totals Per Employee
            <span class="text-xs font-normal text-body ms-2">
                {{ $periodStart->format('d M Y') }} → {{ $periodEnd->format('d M Y') }}
            </span>
        </h6>
    </div>
    <table class="w-full text-sm text-left text-body">
        <thead class="bg-neutral-secondary-soft border-b border-default">
            <tr>
                <th class="px-6 py-3 font-medium">Employee Name</th>
                <th class="px-6 py-3 font-medium">Total Hours This Period</th>
            </tr>
        </thead>
        <tbody>
            @php
                $hoursTotals = $permissions->where('status', 'accepted')
                    ->groupBy('name')
                    ->map(function($group) {
                        $totalMinutes = $group->sum(function($p) {
                            return \Carbon\Carbon::parse($p->from)->diffInMinutes(\Carbon\Carbon::parse($p->to));
                        });
                        return [
                            'name'          => $group->first()->name,
                            'hours'         => intdiv($totalMinutes, 60),
                            'minutes'       => $totalMinutes % 60,
                            'total_minutes' => $totalMinutes,
                        ];
                    });
            @endphp
            @forelse($hoursTotals as $record)
            <tr class="odd:bg-neutral-primary even:bg-neutral-secondary-soft border-b border-default">
                <td class="px-6 py-4 font-medium text-heading">{{ $record['name'] }}</td>
                <td class="px-6 py-4">
                    <span class="bg-blue-100 text-blue-700 text-xs font-medium px-2.5 py-1 rounded-full">
                        {{ $record['hours'] }}h {{ $record['minutes'] }}m
                    </span>
                    @if($record['total_minutes'] > 180)
                        <span class="bg-red-100 text-red-700 text-xs font-medium px-2.5 py-1 rounded-full ms-1">
                            ⚠️ Exceeded 3h
                        </span>
                    @endif
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="2" class="px-6 py-6 text-center text-body">No records this period.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>

<div class="flex justify-end mt-4 mb-2">
    <a href="{{ route('permission.export') }}"
       class="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium px-4 py-2 rounded-lg">
        <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2M7 10l5 5m0 0l5-5m-5 5V4"/>
        </svg>
        Export to Excel
    </a>
</div>
@endif

@endsection