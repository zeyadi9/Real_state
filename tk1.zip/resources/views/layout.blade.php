<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Login App')</title>
    <link href="https://cdn.jsdelivr.net/npm/flowbite@4.0.1/dist/flowbite.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    @yield('styles')

    <style>
        * {
            box-sizing: border-box;
        }

        html, body {
            max-width: 100%;
            overflow-x: hidden;
        }

        body {
            font-family: 'Cairo', sans-serif;
            background: #f8fafc;
            margin: 0;
            padding: 0;
        }

        img, table, iframe, canvas, svg {
            max-width: 100%;
        }

        .main-nav {
            background: #1e3a5f;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 12px rgba(0,0,0,0.18);
            width: 100%;
        }

        .nav-inner {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            min-height: 62px;
            gap: 0.75rem;
        }

        .nav-logo {
            font-size: 1.1rem;
            font-weight: 700;
            color: #fff;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 0.45rem;
            flex-shrink: 0;
            min-width: 0;
        }

        .nav-logo span {
            background: #2563eb;
            color: #fff;
            border-radius: 6px;
            padding: 2px 10px;
            font-size: 0.8rem;
            font-weight: 700;
            flex-shrink: 0;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 0.2rem;
            list-style: none;
            margin: 0;
            padding: 0;
            flex-wrap: wrap;
        }

        .nav-links a,
        .nav-links button {
            display: flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.42rem 0.8rem;
            border-radius: 8px;
            font-family: 'Cairo', sans-serif;
            font-size: 0.86rem;
            font-weight: 600;
            text-decoration: none;
            color: #94a3b8;
            background: transparent;
            border: none;
            cursor: pointer;
            transition: background 0.18s, color 0.18s;
            white-space: nowrap;
        }

        .nav-links a:hover,
        .nav-links button:hover {
            background: rgba(255,255,255,0.08);
            color: #fff;
        }

        .nav-links a.active {
            background: #2563eb;
            color: #fff;
            box-shadow: 0 2px 8px rgba(37,99,235,0.35);
        }

        .nav-separator {
            width: 1px;
            height: 26px;
            background: rgba(255,255,255,0.12);
            margin: 0 0.3rem;
        }

        .btn-logout {
            color: #fca5a5 !important;
        }

        .btn-logout:hover {
            background: rgba(239,68,68,0.2) !important;
            color: #fff !important;
        }

        .btn-login {
            border: 1px solid rgba(255,255,255,0.2) !important;
            color: #e2e8f0 !important;
        }

        .btn-register {
            background: #2563eb !important;
            color: #fff !important;
        }

        .btn-register:hover {
            background: #1d4ed8 !important;
            color: #fff !important;
        }

        .hamburger {
            display: none;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            width: 42px;
            height: 42px;
            border-radius: 10px;
            background: rgba(255,255,255,0.07);
            border: 1px solid rgba(255,255,255,0.14);
            cursor: pointer;
            gap: 5px;
            flex-shrink: 0;
        }

        .hamburger span {
            display: block;
            width: 20px;
            height: 2px;
            background: #fff;
            border-radius: 2px;
            transition: all 0.28s ease;
            transform-origin: center;
        }

        .hamburger.open span:nth-child(1) {
            transform: translateY(7px) rotate(45deg);
        }

        .hamburger.open span:nth-child(2) {
            opacity: 0;
            transform: scaleX(0);
        }

        .hamburger.open span:nth-child(3) {
            transform: translateY(-7px) rotate(-45deg);
        }

        .mobile-current-page {
            display: none;
        }

        .mobile-current-page-text {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 34px;
            padding: 0.35rem 0.8rem;
            border-radius: 999px;
            background: rgba(255,255,255,0.10);
            color: #fff;
            font-size: 0.85rem;
            font-weight: 700;
            white-space: nowrap;
            max-width: 170px;
            overflow: hidden;
            text-overflow: ellipsis;
            box-shadow: 0 2px 8px rgba(0,0,0,0.12);
        }

        .mobile-menu {
            display: none;
            flex-direction: column;
            background: #162d4a;
            border-top: 1px solid rgba(255,255,255,0.07);
            padding: 0.65rem 0.85rem 0.9rem;
            gap: 0.3rem;
            width: 100%;
        }

        .mobile-menu.open {
            display: flex;
            animation: slideDown 0.22s ease;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-6px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .mobile-menu a,
        .mobile-menu button {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.8rem 0.95rem;
            border-radius: 10px;
            font-family: 'Cairo', sans-serif;
            font-size: 0.95rem;
            font-weight: 600;
            text-decoration: none;
            color: #cbd5e1;
            background: transparent;
            border: none;
            cursor: pointer;
            width: 100%;
            text-align: right;
            transition: background 0.15s, color 0.15s;
        }

        .mobile-menu a:hover,
        .mobile-menu button:hover {
            background: rgba(255,255,255,0.07);
            color: #fff;
        }

        .mobile-menu a.active {
            background: #2563eb;
            color: #fff;
        }

        .mobile-separator {
            height: 1px;
            background: rgba(255,255,255,0.09);
            margin: 0.35rem 0;
        }

        .page-content {
            width: 100%;
            max-width: 100%;
            padding: 14px;
            overflow-x: hidden;
        }

        .footer-bar {
            width: 100%;
            background: #1e3a5f;
            color: #e2e8f0;
            border-top: 1px solid rgba(255,255,255,0.08);
            margin-top: 18px;
        }

        .footer-inner {
            max-width: 1200px;
            margin: 0 auto;
            padding: 14px 16px;
            text-align: center;
            font-size: 0.92rem;
            line-height: 1.8;
        }

        .footer-inner a {
            color: #93c5fd;
            text-decoration: none;
        }

        .footer-inner a:hover {
            text-decoration: underline;
        }

        @media (min-width: 768px) {
            .page-content {
                padding: 20px;
            }
        }

        @media (max-width: 900px) {
            .nav-inner {
                min-height: 56px;
                padding: 0 0.85rem;
                display: grid;
                grid-template-columns: auto 1fr auto;
                align-items: center;
                gap: 0.5rem;
            }

            .nav-links {
                display: none;
            }

            .hamburger {
                display: flex;
            }

            .nav-logo {
                font-size: 0.98rem;
                gap: 0.4rem;
            }

            .nav-logo span {
                font-size: 0.72rem;
                padding: 2px 8px;
            }

            .mobile-current-page {
                display: flex;
                align-items: center;
                justify-content: center;
                min-width: 0;
                flex: 1;
            }

            .mobile-current-page-text {
                max-width: 100%;
            }
        }

        @media (max-width: 576px) {
            .nav-inner {
                min-height: 54px;
                padding: 0 0.75rem;
            }

            .nav-logo {
                font-size: 0.92rem;
            }

            .nav-logo span {
                font-size: 0.68rem;
                padding: 2px 7px;
            }

            .mobile-menu {
                padding: 0.55rem 0.7rem 0.8rem;
            }

            .mobile-menu a,
            .mobile-menu button {
                font-size: 0.9rem;
                padding: 0.78rem 0.85rem;
            }

            .mobile-current-page-text {
                font-size: 0.8rem;
                padding: 0.32rem 0.65rem;
                max-width: 135px;
            }

            .page-content {
                padding: 12px;
            }

            .footer-inner {
                font-size: 0.84rem;
                padding: 12px 14px;
            }
        }

        @media (min-width: 901px) {
            .mobile-current-page {
                display: none !important;
            }
        }
    </style>
</head>
<body>

@php
    $currentPageLabel = match(true) {
        request()->routeIs('leave') => 'اجازات',
        request()->routeIs('permission') => 'اذونات',
        request()->routeIs('Overtime') => 'اضافي',
        request()->routeIs('view_Overtime') => 'عرض الاضافي',
        request()->routeIs('view_leave') => 'عرض الاجازات',
        request()->routeIs('view_permission') => 'عرض الاذونات',
        request()->routeIs('login') => 'تسجيل الدخول',
        request()->routeIs('register') => 'إنشاء حساب',
        default => 'الرئيسية',
    };
@endphp

<nav class="main-nav">
    <div class="nav-inner">
        <a href="/" class="nav-logo">
            <span>HR</span> System
        </a>

        <div class="mobile-current-page">
            <span class="mobile-current-page-text">{{ $currentPageLabel }}</span>
        </div>

        @auth
        <ul class="nav-links">
            <li><a href="{{ route('leave') }}" class="{{ request()->routeIs('leave') ? 'active' : '' }}">🏖️ اجازات</a></li>
            <li><a href="{{ route('permission') }}" class="{{ request()->routeIs('permission') ? 'active' : '' }}">📋 اذونات</a></li>
            <li><a href="{{ route('Overtime') }}" class="{{ request()->routeIs('Overtime') ? 'active' : '' }}">⏱️ اضافي</a></li>
            <li><div class="nav-separator"></div></li>
            <li><a href="{{ route('view_Overtime') }}" class="{{ request()->routeIs('view_Overtime') ? 'active' : '' }}">📊 عرض الاضافي</a></li>
            <li><a href="{{ route('view_leave') }}" class="{{ request()->routeIs('view_leave') ? 'active' : '' }}">📅 عرض الاجازات</a></li>
            <li><a href="{{ route('view_permission') }}" class="{{ request()->routeIs('view_permission') ? 'active' : '' }}">📝 عرض الاذونات</a></li>
            <li><div class="nav-separator"></div></li>
            <li>
                <form action="{{ route('logout') }}" method="POST">
                    @csrf
                    <button type="submit" class="btn-logout">🚪 Logout</button>
                </form>
            </li>
        </ul>
        @else
        <ul class="nav-links">
            <li><a href="{{ route('login') }}" class="btn-login {{ request()->routeIs('login') ? 'active' : '' }}">🔑 Log In</a></li>
            <li><a href="{{ route('register') }}" class="btn-register {{ request()->routeIs('register') ? 'active' : '' }}">✨ Register</a></li>
        </ul>
        @endauth

        <button class="hamburger" id="hamburgerBtn" aria-label="Toggle menu" type="button">
            <span></span><span></span><span></span>
        </button>
    </div>

    <div class="mobile-menu" id="mobileMenu">
        @auth
            <a href="{{ route('leave') }}" class="{{ request()->routeIs('leave') ? 'active' : '' }}">🏖️ اجازات</a>
            <a href="{{ route('permission') }}" class="{{ request()->routeIs('permission') ? 'active' : '' }}">📋 اذونات</a>
            <a href="{{ route('Overtime') }}" class="{{ request()->routeIs('Overtime') ? 'active' : '' }}">⏱️ اضافي</a>
            <div class="mobile-separator"></div>
            <a href="{{ route('view_Overtime') }}" class="{{ request()->routeIs('view_Overtime') ? 'active' : '' }}">📊 عرض الاضافي</a>
            <a href="{{ route('view_leave') }}" class="{{ request()->routeIs('view_leave') ? 'active' : '' }}">📅 عرض الاجازات</a>
            <a href="{{ route('view_permission') }}" class="{{ request()->routeIs('view_permission') ? 'active' : '' }}">📝 عرض الاذونات</a>
            <div class="mobile-separator"></div>
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button type="submit" class="btn-logout">🚪 Logout</button>
            </form>
        @else
            <a href="{{ route('login') }}" class="{{ request()->routeIs('login') ? 'active' : '' }}">🔑 Log In</a>
            <a href="{{ route('register') }}" class="{{ request()->routeIs('register') ? 'active' : '' }}">✨ Register</a>
        @endauth
    </div>
</nav>

<div class="page-content">
    @yield('content')
</div>

<footer class="footer-bar">
    <div class="footer-inner">
        Copyright © {{ date('Y') }} — Zeyad Yasser, IT Manager @ Gamma Scan Center<br>
        WhatsApp: <a href="https://wa.me/201024474059" target="_blank" rel="noopener noreferrer">wa.me/201024474059</a>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/flowbite@4.0.1/dist/flowbite.min.js"></script>
<script>
    const btn = document.getElementById('hamburgerBtn');
    const menu = document.getElementById('mobileMenu');

    if (btn && menu) {
        btn.addEventListener('click', () => {
            btn.classList.toggle('open');
            menu.classList.toggle('open');
        });

        document.addEventListener('click', (e) => {
            if (!btn.contains(e.target) && !menu.contains(e.target)) {
                btn.classList.remove('open');
                menu.classList.remove('open');
            }
        });
    }
</script>
</body>
</html>