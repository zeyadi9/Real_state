@extends('layout')
@section('title', 'View Leaves')
@section('content')

<div class="relative overflow-x-auto bg-neutral-primary-soft shadow-xs rounded-base border border-default mt-20">
    <table class="w-full text-sm text-left rtl:text-right text-body">
        <thead class="bg-neutral-secondary-soft border-b border-default">
            <tr>
                <th class="px-6 py-3 font-medium">N</th>
                <th class="px-6 py-3 font-medium">Employee Name</th>
                <th class="px-6 py-3 font-medium">Date</th>
                <th class="px-6 py-3 font-medium">Day</th>
                <th class="px-6 py-3 font-medium">Days Count</th>
                <th class="px-6 py-3 font-medium">Reason</th>
                <th class="px-6 py-3 font-medium">Substitute</th>
                <th class="px-6 py-3 font-medium">Status</th>
                @if(Auth::user()->role === 'admin')
                <th class="px-6 py-3 font-medium">Actions</th>
                @endif
                <th class="px-6 py-3 font-medium">Create At</th>
            </tr>
            
        </thead>
        <tbody>
            @forelse($leaves as $index => $item)
            <tr class="odd:bg-neutral-primary even:bg-neutral-secondary-soft border-b border-default">
                <td class="px-6 py-4">{{ $index + 1 }}</td>
                <td class="px-6 py-4 font-medium text-heading">{{ $item->name }}</td>
                <td class="px-6 py-4">{{ \Carbon\Carbon::parse($item->date)->format('d M Y') }}</td>
                <td class="px-6 py-4">{{ $item->day }}</td>
                <td class="px-6 py-4">{{ $item->days_count }} days</td>
                <td class="px-6 py-4">{{ $item->reason }}</td>
                <td class="px-6 py-4">{{ $item->substitute }}</td>
                <td class="px-6 py-4">
                    @if($item->status === 'accepted')
                        <span class="bg-green-100 text-green-700 text-xs font-medium px-2.5 py-1 rounded-full">Accepted</span>
                    @elseif($item->status === 'refused')
                        <span class="bg-red-100 text-red-700 text-xs font-medium px-2.5 py-1 rounded-full">Refused</span>
                    @else
                        <span class="bg-yellow-100 text-yellow-700 text-xs font-medium px-2.5 py-1 rounded-full">Pending</span>
                    @endif
                </td>
                @if(Auth::user()->role === 'admin')
                <td class="px-6 py-4">
                    @if($item->status === 'pending')
                        <div class="flex gap-2">
                            <form action="{{ route('leave.accept', $item->id) }}" method="POST">
                                @csrf
                                <button type="submit" class="text-white bg-green-600 hover:bg-green-700 text-sm px-3 py-1.5 rounded">Accept</button>
                            </form>
                            <button type="button"
                                onclick="document.getElementById('leaveRefuseModal{{ $item->id }}').classList.remove('hidden')"
                                class="text-white bg-red-600 hover:bg-red-700 text-sm px-3 py-1.5 rounded">
                                Refuse
                            </button>
                        </div>
                        <div id="leaveRefuseModal{{ $item->id }}" class="hidden fixed inset-0 z-50 items-center justify-center bg-black bg-opacity-50">
                            <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
                                <h5 class="text-lg font-semibold mb-4">Reason for Refusal</h5>
                                <form action="{{ route('leave.refuse', $item->id) }}" method="POST">
                                    @csrf
                                    <textarea name="refuse_reason" rows="4" required placeholder="Enter reason..."
                                        class="w-full border border-gray-300 rounded-lg p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-red-400 mb-4"></textarea>
                                    <div class="flex justify-end gap-2">
                                        <button type="button"
                                            onclick="document.getElementById('leaveRefuseModal{{ $item->id }}').classList.add('hidden')"
                                            class="px-4 py-2 text-sm bg-gray-200 hover:bg-gray-300 rounded">Cancel</button>
                                        <button type="submit" class="px-4 py-2 text-sm text-white bg-red-600 hover:bg-red-700 rounded">Confirm Refuse</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        @else
                        <span class="text-gray-400 text-xs">Done</span>
                        @endif
                    </td>
                    <td class="px-6 py-4">{{ $item->created_at->toDateString() }}</td>
                @endif
            </tr>
            @if($item->status === 'refused' && $item->refuse_reason)
            <tr class="bg-red-50 border-b border-default">
                <td colspan="{{ Auth::user()->role === 'admin' ? 9 : 8 }}" class="px-6 py-2">
                    <span class="text-red-600 text-xs font-medium">Refuse Reason: </span>
                    <span class="text-red-500 text-xs">{{ $item->refuse_reason }}</span>
                </td>

                
            </tr>
            @endif
            @empty
            <tr>
                <td colspan="9" class="px-6 py-6 text-center text-body">No leave records found.</td>
            </tr>
            @endforelse
        </tbody>
        <tfoot>
            <tr class="bg-neutral-secondary-soft font-semibold">
                <td colspan="2" class="px-6 py-4 text-heading">
                    Annual Total
                    <span class="text-xs font-normal text-body block">{{ now()->format('Y') }}</span>
                </td>
                <td colspan="2" class="px-6 py-4 text-heading">
                    {{ $leaves->where('status', 'accepted')->sum('days_count') }} days
                </td>
                <td colspan="5"></td>
            </tr>
        </tfoot>
    </table>
</div>

@if(Auth::user()->role === 'admin')
<div class="relative overflow-x-auto bg-neutral-primary-soft shadow-xs rounded-base border border-default mt-6">
    <div class="px-6 py-3 bg-neutral-secondary-soft border-b border-default">
        <h6 class="font-semibold text-heading">Annual Leave Totals Per Employee <span class="text-xs font-normal text-body">{{ now()->format('Y') }}</span></h6>
    </div>
    <table class="w-full text-sm text-left text-body">
        <thead class="bg-neutral-secondary-soft border-b border-default">
            <tr>
                <th class="px-6 py-3 font-medium">Employee Name</th>
                <th class="px-6 py-3 font-medium">Total Days This Year</th>
            </tr>
        </thead>
        <tbody>
            @php
                $annualTotals = $leaves->where('status', 'accepted')
                    ->groupBy('name')
                    ->map(fn($g) => ['name' => $g->first()->name, 'total' => $g->sum('days_count')]);
            @endphp
            @forelse($annualTotals as $record)
            <tr class="odd:bg-neutral-primary even:bg-neutral-secondary-soft border-b border-default">
                <td class="px-6 py-4">{{ $record['name'] }}</td>
                <td class="px-6 py-4">
                    <span class="bg-blue-100 text-blue-700 text-xs font-medium px-2.5 py-1 rounded-full">
                        {{ $record['total'] }} days
                    </span>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="2" class="px-6 py-6 text-center text-body">No records.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>

@if(Auth::user()->role === 'admin')
<div class="flex justify-end mt-4 mb-2">
    <a href="{{ route('leave.export') }}"
       class="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium px-4 py-2 rounded-lg">
        <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2M7 10l5 5m0 0l5-5m-5 5V4"/>
        </svg>
        Export to Excel
    </a>
</div>
@endif
@endif

@endsection
