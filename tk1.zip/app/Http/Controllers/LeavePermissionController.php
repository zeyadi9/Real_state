<?php
namespace App\Http\Controllers;

use App\Models\Leave;
use App\Models\Permission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Exports\LeavesExport;
use App\Exports\PermissionsExport;
use Maatwebsite\Excel\Facades\Excel;
use App\Support\SubmissionWindow;


class LeavePermissionController extends Controller
{
    // ---- LEAVE ----
    public function leave_index()
    {
        return view('agaza', ['dateBounds' => SubmissionWindow::bounds()]);
    }

    public function leave_post(Request $request)
    {
        $request->validate([
            'date'       => 'required|date',
            'day'        => 'required|string',
            'reason'     => 'required|string|max:1000',
            'substitute' => 'required|string|max:255',
            'days_count' => 'required|integer|min:1',
        ]);

        SubmissionWindow::assertDateWithinAllowedWindow($request->date, 'Leave date');

        Leave::create([
            'user_id'    => Auth::id(),
            'name'       => Auth::user()->name,
            'date'       => $request->date,
            'day'        => $request->day,
            'reason'     => $request->reason,
            'substitute' => $request->substitute,
            'days_count' => $request->days_count,
        ]);

        return redirect()->route('home')->with('success', 'Leave submitted successfully!');
    }

    public function leave_accept($id)
    {
        Leave::findOrFail($id)->update(['status' => 'accepted']);
        return redirect()->route('view_leave')->with('success', 'Leave accepted.');
    }

    public function leave_refuse(Request $request, $id)
    {
        $request->validate(['refuse_reason' => 'required|string|max:500']);
        Leave::findOrFail($id)->update([
            'status'        => 'refused',
            'refuse_reason' => $request->refuse_reason,
        ]);
        return redirect()->route('view_leave')->with('success', 'Leave refused.');
    }

    public function view_leave()
    {
        if (Auth::user()->role === 'admin') {
            $leaves = Leave::latest()->get();
        } else {
            $leaves = Leave::where('user_id', Auth::id())->latest()->get();
        }
        return view('view_agaza', compact('leaves'));
    }

    // ---- PERMISSION ----
    public function permission_index()
    {
        return view('ezn', ['dateBounds' => SubmissionWindow::bounds()]);
    }

    public function permission_post(Request $request)
    {
        $request->validate([
            'date'   => 'required|date',
            'day'    => 'required|string',
            'reason' => 'required|string|max:1000',
            'from'   => 'required|date_format:H:i',
            'to'     => 'required|date_format:H:i|after:from',
        ]);

        SubmissionWindow::assertDateWithinAllowedWindow($request->date, 'Permission date');

        Permission::create([
            'user_id' => Auth::id(),
            'name'    => Auth::user()->name,
            'date'    => $request->date,
            'day'     => $request->day,
            'reason'  => $request->reason,
            'from'    => $request->from,
            'to'      => $request->to,
        ]);

        return redirect()->route('home')->with('success', 'Permission submitted successfully!');
    }

    public function permission_accept($id)
    {
        Permission::findOrFail($id)->update(['status' => 'accepted']);
        return redirect()->route('view_permission')->with('success', 'Permission accepted.');
    }

    public function permission_refuse(Request $request, $id)
    {
        $request->validate(['refuse_reason' => 'required|string|max:500']);
        Permission::findOrFail($id)->update([
            'status'        => 'refused',
            'refuse_reason' => $request->refuse_reason,
        ]);
        return redirect()->route('view_permission')->with('success', 'Permission refused.');
    }

public function view_permission()
{
    $today = \Carbon\Carbon::today();
    $periodStart = $today->day >= 26
        ? $today->copy()->day(26)
        : $today->copy()->subMonth()->day(26);
    $periodEnd = $periodStart->copy()->addMonth()->day(25)->endOfDay();

    if (Auth::user()->role === 'admin') {
        $permissions = Permission::latest()->get();
        $monthlyTotals = Permission::whereBetween('date', [$periodStart, $periodEnd])
            ->where('status', 'accepted')
            ->selectRaw('user_id, COUNT(*) as total')
            ->groupBy('user_id')
            ->with('user')
            ->get();
    } else {
        $permissions = Permission::where('user_id', Auth::id())->latest()->get();
        $monthlyTotals = collect();
    }

    return view('view_ezn', compact('permissions', 'monthlyTotals', 'periodStart', 'periodEnd'));
}


public function export_lev()
{
    $leaves = Leave::whereYear('date', now()->year)->get();
    $filename = 'leaves_' . now()->format('Y') . '.xlsx';

    return Excel::download(
        new LeavesExport($leaves, now()->format('Y')),
        $filename
    );
}


public function export_per()
{
    $periodStart = now()->startOfMonth();
    $periodEnd   = now()->endOfMonth();

    $permissions = Permission::whereBetween('date', [$periodStart, $periodEnd])->get();

    $monthlyTotals = Permission::with('user')
        ->whereBetween('date', [$periodStart, $periodEnd])
        ->where('status', 'accepted')
        ->selectRaw('user_id, COUNT(*) as total')
        ->groupBy('user_id')
        ->get();

    return Excel::download(
        new PermissionsExport($permissions, $monthlyTotals, $periodStart, $periodEnd),
        'permissions_' . $periodStart->format('M_Y') . '.xlsx'
    );
}
}