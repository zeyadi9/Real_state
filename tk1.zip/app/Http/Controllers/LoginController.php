<?php


namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    function login(){
        return view('login');
    }
    function register(){
        return view('register');
    }


    function register_post(Request $request){
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:6'
        ]);

        $data['name'] = $request->name;
        $data['email'] = $request->email;
        $data['password'] = bcrypt($request->password);
        $user = User::create($data);
        if($user){
            return redirect()->intended(route('login'))->with('success','Registration successful, you can now login');
            }
            return redirect()->intended(route('register'))->withErrors(['email'=>'Registration failed']);
    }

function login_post(Request $request){
    $request->validate([
        'email'    => 'required|email',
        'password' => 'required',
    ]);

    $credentials = $request->only('email', 'password');

    if(Auth::attempt($credentials)){
        $request->session()->regenerate();

        if(Auth::user()->role === 'admin'){
            return redirect()->route('home');
        } else {
            return redirect()->route('home');
        }
    }

    return back()->withErrors(['email' => 'Invalid credentials.']);
}

    function logout(){
        Auth::logout();
        return redirect()->intended(route('login'));
    }


}
