@extends('layout')
@section('title', 'View Overtime')
@section('content')

<div class="max-w-7xl mx-auto px-4 mt-8">
    <div class="bg-white border border-default rounded-base shadow-xs p-5 mb-6">
        <div class="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
                <h1 class="text-xl font-semibold text-heading">Overtime Cycle View</h1>
                <p class="text-sm text-body mt-1">
                    الدورة الحالية للإضافي تتحسب من يوم 26 إلى يوم 25.
                </p>
                <p class="text-sm font-medium text-heading mt-2">
                    الفترة المعروضة: {{ $periodLabel }}
                    @if($isCurrentPeriod)
                        <span class="ms-2 inline-flex items-center rounded-full bg-green-100 px-2.5 py-1 text-xs font-medium text-green-700">
                            Current Cycle
                        </span>
                    @else
                        <span class="ms-2 inline-flex items-center rounded-full bg-blue-100 px-2.5 py-1 text-xs font-medium text-blue-700">
                            Archived Cycle
                        </span>
                    @endif
                </p>
            </div>

            <div class="flex flex-wrap gap-2">
                <a href="{{ route('view_Overtime', ['period_start' => $previousPeriodStart]) }}"
                   class="inline-flex items-center rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">
                    الدورة السابقة
                </a>

                @unless($isCurrentPeriod)
                    <a href="{{ route('view_Overtime', ['period_start' => $nextPeriodStart]) }}"
                       class="inline-flex items-center rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">
                        الدورة التالية
                    </a>
                @endunless

                <a href="{{ route('view_Overtime') }}"
                   class="inline-flex items-center rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700">
                    العودة للدورة الحالية
                </a>
            </div>
        </div>

        @if(Auth::user()->role === 'admin' && $olderPendingCount > 0)
            <div class="mt-4 rounded-lg border border-yellow-200 bg-yellow-50 px-4 py-3 text-sm text-yellow-800">
                يوجد {{ $olderPendingCount }} طلب إضافي Pending من فترات أقدم.
                يمكنك مراجعتها من خلال زر <span class="font-semibold">الدورة السابقة</span>.
            </div>
        @endif
    </div>

    <div class="relative overflow-x-auto bg-neutral-primary-soft shadow-xs rounded-base border border-default">
        <table class="w-full text-sm text-left rtl:text-right text-body">
            <thead class="bg-neutral-secondary-soft border-b border-default">
                <tr>
                    <th scope="col" class="px-6 py-3 font-medium">N</th>
                    <th scope="col" class="px-6 py-3 font-medium">Employee Name</th>
                    <th scope="col" class="px-6 py-3 font-medium">Total Hours</th>
                    <th scope="col" class="px-6 py-3 font-medium">Reason</th>
                    <th scope="col" class="px-6 py-3 font-medium">Date</th>
                    <th scope="col" class="px-6 py-3 font-medium">Day</th>
                    <th scope="col" class="px-6 py-3 font-medium">From</th>
                    <th scope="col" class="px-6 py-3 font-medium">To</th>
                    <th scope="col" class="px-6 py-3 font-medium">Duration</th>
                    <th scope="col" class="px-6 py-3 font-medium">Status</th>
                    @if(Auth::user()->role === 'admin')
                        <th scope="col" class="px-6 py-3 font-medium">Actions</th>
                    @endif
                    <th class="px-6 py-3 font-medium">Created At</th>
                </tr>
            </thead>
            <tbody>
                @forelse($Overtime as $index => $item)
                    <tr class="odd:bg-neutral-primary even:bg-neutral-secondary-soft border-b border-default">
                        <td class="px-6 py-4">{{ $index + 1 }}</td>
                        <th scope="row" class="px-6 py-4 font-medium text-heading whitespace-nowrap">
                            {{ $item->name }}
                        </th>
                        <td class="px-6 py-4">{{ $item->total_hours }} hrs</td>
                        <td class="px-6 py-4">{{ $item->reason }}</td>
                        <td class="px-6 py-4">{{ \Carbon\Carbon::parse($item->date)->format('d M Y') }}</td>
                        <td class="px-6 py-4">{{ $item->day }}</td>
                        <td class="px-6 py-4">
                            {{ $item->from
                                ? date('h:i', strtotime($item->from)) . (date('A', strtotime($item->from)) == 'AM' ? ' ص' : ' م')
                                : '-'
                            }}
                        </td>

                        <td class="px-6 py-4">
                            {{ $item->to
                                ? date('h:i', strtotime($item->to)) . (date('A', strtotime($item->to)) == 'AM' ? ' ص' : ' م')
                                : '-'
                            }}
                        </td>
                        <td class="px-6 py-4">
                            @php
                                $from = \Carbon\Carbon::parse($item->from);
                                $to = \Carbon\Carbon::parse($item->to);
                                $diff = $from->diffInMinutes($to);
                                $h = intdiv($diff, 60);
                                $m = $diff % 60;
                            @endphp
                            <span class="bg-purple-100 text-purple-700 text-xs font-medium px-2.5 py-1 rounded-full">
                                {{ $h }}h {{ $m }}m
                            </span>
                        </td>
                        <td class="px-6 py-4">
                            @if($item->status === 'accepted')
                                <span class="bg-green-100 text-green-700 text-xs font-medium px-2.5 py-1 rounded-full">Accepted</span>
                            @elseif($item->status === 'refused')
                                <span class="bg-red-100 text-red-700 text-xs font-medium px-2.5 py-1 rounded-full">Refused</span>
                            @else
                                <span class="bg-yellow-100 text-yellow-700 text-xs font-medium px-2.5 py-1 rounded-full">Pending</span>
                            @endif
                        </td>

                        @if(Auth::user()->role === 'admin')
                            <td class="px-6 py-4">
                                @if($item->status === 'pending')
                                    <div class="flex gap-2">
                                        <form action="{{ route('overtime.accept', $item->id) }}" method="POST">
                                            @csrf
                                            <button type="submit" class="text-white bg-green-600 hover:bg-green-700 text-sm px-3 py-1.5 rounded">Accept</button>
                                        </form>
                                        <button type="button"
                                            onclick="document.getElementById('refuseModal{{ $item->id }}').classList.remove('hidden')"
                                            class="text-white bg-red-600 hover:bg-red-700 text-sm px-3 py-1.5 rounded">
                                            Refuse
                                        </button>
                                    </div>
                                    <div id="refuseModal{{ $item->id }}" class="hidden fixed inset-0 z-50 items-center justify-center bg-black bg-opacity-50">
                                        <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
                                            <h5 class="text-lg font-semibold mb-4">Reason for Refusal</h5>
                                            <form action="{{ route('overtime.refuse', $item->id) }}" method="POST">
                                                @csrf
                                                <textarea
                                                    name="refuse_reason"
                                                    rows="4"
                                                    required
                                                    placeholder="Enter reason for refusal..."
                                                    class="w-full border border-gray-300 rounded-lg p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-red-400 mb-4"
                                                ></textarea>
                                                <div class="flex justify-end gap-2">
                                                    <button type="button"
                                                        onclick="document.getElementById('refuseModal{{ $item->id }}').classList.add('hidden')"
                                                        class="px-4 py-2 text-sm bg-gray-200 hover:bg-gray-300 rounded">
                                                        Cancel
                                                    </button>
                                                    <button type="submit"
                                                        class="px-4 py-2 text-sm text-white bg-red-600 hover:bg-red-700 rounded">
                                                        Confirm Refuse
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                @else
                                    <span class="text-gray-400 text-xs">Done</span>
                                @endif
                            </td>
                        @endif

                        <td class="px-6 py-4">{{ $item->created_at->toDateString() }}</td>
                    </tr>

                    @if($item->status === 'refused' && $item->refuse_reason)
                        <tr class="bg-red-50 border-b border-default">
                            <td colspan="{{ Auth::user()->role === 'admin' ? 12 : 11 }}" class="px-6 py-2">
                                <span class="text-red-600 text-xs font-medium">Refuse Reason: </span>
                                <span class="text-red-500 text-xs">{{ $item->refuse_reason }}</span>
                            </td>
                        </tr>
                    @endif
                @empty
                    <tr>
                        <td colspan="{{ Auth::user()->role === 'admin' ? 12 : 11 }}" class="px-6 py-6 text-center text-body">
                            No overtime records found for this cycle.
                        </td>
                    </tr>
                @endforelse
            </tbody>

            <tfoot>
                <tr class="bg-neutral-secondary-soft font-semibold">
                    <td colspan="2" class="px-6 py-4 text-heading">
                        Total This Period
                        <span class="text-xs font-normal text-body block">
                            {{ $periodStart->format('d M Y') }} → {{ $periodEnd->format('d M Y') }}
                        </span>
                    </td>
                    <td class="px-6 py-4 text-heading">
                        @if(Auth::user()->role === 'admin')
                            {{ round($monthlyTotals->sum('total'), 2) }} hrs
                        @else
                            {{ round($monthlyTotals->first()->total ?? 0, 2) }} hrs
                        @endif
                    </td>
                    <td colspan="{{ Auth::user()->role === 'admin' ? 9 : 8 }}"></td>
                </tr>
            </tfoot>
        </table>
    </div>

    @if(Auth::user()->role === 'admin')
        <div class="relative overflow-x-auto bg-neutral-primary-soft shadow-xs rounded-base border border-default mt-6">
            <div class="px-6 py-3 bg-neutral-secondary-soft border-b border-default flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
                <h6 class="font-semibold text-heading">
                    Totals Per Employee
                    <span class="text-xs font-normal text-body ms-2">
                        {{ $periodStart->format('d M Y') }} → {{ $periodEnd->format('d M Y') }}
                    </span>
                </h6>
            </div>
            <table class="w-full text-sm text-left text-body">
                <thead class="bg-neutral-secondary-soft border-b border-default">
                    <tr>
                        <th class="px-6 py-3 font-medium">Employee Name</th>
                        <th class="px-6 py-3 font-medium">Accepted Hours This Cycle</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($monthlyTotals as $record)
                        <tr class="odd:bg-neutral-primary even:bg-neutral-secondary-soft border-b border-default">
                            <td class="px-6 py-4 font-medium text-heading">{{ $record->user->name ?? 'Unknown' }}</td>
                            <td class="px-6 py-4">
                                <span class="bg-blue-100 text-blue-700 text-xs font-medium px-2.5 py-1 rounded-full">
                                    {{ round($record->total, 2) }} hrs
                                </span>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="2" class="px-6 py-6 text-center text-body">No accepted overtime in this cycle.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="flex justify-end mt-4 mb-8">
            <a href="{{ route('overtime.export', ['period_start' => $selectedPeriodStart]) }}"
               class="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium px-4 py-2 rounded-lg">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2M7 10l5 5m0 0l5-5m-5 5V4"/>
                </svg>
                Export displayed cycle
            </a>
        </div>
    @endif
</div>

@endsection
