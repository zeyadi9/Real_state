@extends('layout')

@section('title', 'Overtime')
@section('content')


@if($errors->any())
    @foreach($errors->all() as $error)
        <div class="alert alert-danger">
            {{ $error }}
        </div>
    @endforeach
@endif


<form class="max-w-md mx-auto mt-40" action="{{ route('overtime_post') }}" method="POST">
    @csrf
    <div class="grid md:grid-cols-2 md:gap-6">
        <div class="mb-3">
            <label for="date" class="block mb-2.5 text-sm font-medium text-heading">التاريخ</label>
            <input type="date" name="date" id="date" min="{{ $dateBounds['min'] }}" max="{{ $dateBounds['max'] }}" value="{{ old('date', $dateBounds['max']) }}" class="bg-neutral-secondary-medium border border-default-medium text-heading text-sm rounded-base focus:ring-brand focus:border-brand block w-full px-3 py-2.5 shadow-xs placeholder:text-body" required />
            <p class="mt-1 text-xs text-body">Allowed dates: today or yesterday only.</p>
        </div>
        <div class="mb-3">
            <label for="day" class="block mb-2.5 text-sm font-medium text-heading">اليوم</label>
            <input type="text" name="day" id="day" class="bg-neutral-secondary-medium border border-default-medium text-heading text-sm rounded-base focus:ring-brand focus:border-brand block w-full px-3 py-2.5 shadow-xs placeholder:text-body" required />
        </div>
    </div>

    <div class="mb-3" hidden>
        <label for="name" class="block mb-2.5 text-sm font-medium text-heading">Name</label>
        <input type="text" name="name" id="name" value="{{ Auth::user()->name }}" hidden class="bg-neutral-secondary-medium border border-default-medium text-heading text-sm rounded-base focus:ring-brand focus:border-brand block w-full px-3 py-2.5 shadow-xs placeholder:text-body" required />
    </div>


    <div class="mb-3" hidden>
        <label for="total_hours" class="block mb-2.5 text-sm font-medium text-heading">total Hours</label>
        <input type="number" name="total_hours" id="total_hours" readonly  class="bg-neutral-secondary-medium border border-default-medium text-heading text-sm rounded-base focus:ring-brand focus:border-brand block w-full px-3 py-2.5 shadow-xs placeholder:text-body" required />
    </div>

    <div class="mb-3">
        <label for="reason" class="block mb-2.5 text-sm font-medium text-heading">السبب</label>
        <input type="text" name="reason" id="reason" class="bg-neutral-secondary-medium border border-default-medium text-heading text-sm rounded-base focus:ring-brand focus:border-brand block w-full px-3 py-2.5 shadow-xs placeholder:text-body" required />
    </div>

<div class="grid grid-cols-2 gap-3 max-w-[260px] sm:max-w-[320px] md:max-w-none">
    <div class="mb-3">
        <label for="from" class="block mb-2 text-sm font-medium text-heading">من</label>
        <input
            type="time"
            name="from"
            id="from"
            class="bg-neutral-secondary-medium border border-default-medium text-heading text-sm rounded-base focus:ring-brand focus:border-brand block w-full px-2 py-2 shadow-xs placeholder:text-body"
            required
        />
    </div>

    <div class="mb-3">
        <label for="to" class="block mb-2 text-sm font-medium text-heading">الى</label>
        <input
            type="time"
            name="to"
            id="to"
            class="bg-neutral-secondary-medium border border-default-medium text-heading text-sm rounded-base focus:ring-brand focus:border-brand block w-full px-2 py-2 shadow-xs placeholder:text-body"
            required
        />
    </div>
</div>

    <button type="submit" class="text-white bg-gradient-to-l from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 focus:ring-4 focus:ring-blue-300 font-semibold rounded-xl text-sm px-5 py-2.5 shadow-md transition-all duration-200"> Submit </botton>

</form>



@endsection
