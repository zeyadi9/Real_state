<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Leave extends Model
{
    protected $fillable = [
        'user_id', 'date', 'day', 'name',
        'reason', 'substitute', 'days_count',
        'status', 'refuse_reason',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
