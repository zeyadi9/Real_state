<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Permission extends Model
{
    protected $fillable = [
        'user_id', 'date', 'day', 'name',
        'reason', 'from', 'to',
        'status', 'refuse_reason',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
