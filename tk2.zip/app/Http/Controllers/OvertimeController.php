<?php

namespace App\Http\Controllers;

use App\Exports\OvertimeExport;
use App\Models\Overtime;
use App\Support\PayrollPeriod;
use App\Support\SubmissionWindow;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;

class OvertimeController extends Controller
{
    public function overtime()
    {
        return view('overtime', ['dateBounds' => SubmissionWindow::bounds()]);
    }

    public function overtime_post(Request $request)
    {
        $request->validate([
            'date' => 'required|date',
            'day' => 'required|string|max:255',
            'reason' => 'required|string|max:1000',
            'from' => 'required|date_format:H:i',
            'to' => 'required|date_format:H:i|after:from',
        ]);

        SubmissionWindow::assertDateWithinAllowedWindow($request->date, 'Overtime date');

        $from = \Carbon\Carbon::createFromFormat('H:i', $request->from);
        $to = \Carbon\Carbon::createFromFormat('H:i', $request->to);
        $total_hours = round($from->diffInMinutes($to) / 60, 2);

        $over = Overtime::create([
            'user_id' => Auth::id(),
            'name' => Auth::user()->name,
            'date' => $request->date,
            'day' => $request->day,
            'total_hours' => $total_hours,
            'reason' => $request->reason,
            'from' => $request->from,
            'to' => $request->to,
        ]);

        if ($over) {
            return redirect()->route('home')->with('success', 'Overtime submitted successfully!');
        }

        return redirect()->route('Overtime')->withErrors(['error' => 'Overtime submission failed']);
    }

    public function accept($id)
    {
        Overtime::findOrFail($id)->update(['status' => 'accepted']);

        return redirect()->route('view_Overtime')->with('success', 'Overtime accepted.');
    }

    public function refuse(Request $request, $id)
    {
        $request->validate([
            'refuse_reason' => 'required|string|max:500',
        ]);

        Overtime::findOrFail($id)->update([
            'status' => 'refused',
            'refuse_reason' => $request->refuse_reason,
        ]);

        return redirect()->route('view_Overtime')->with('success', 'Overtime refused.');
    }

    public function export(Request $request)
    {
        $period = PayrollPeriod::fromRequest($request->query('period_start'));
        $periodStart = $period['start'];
        $periodEnd = $period['end'];

        $overtimeQuery = Overtime::with('user')
            ->whereBetween('date', [
                $periodStart->toDateString(),
                $periodEnd->toDateString(),
            ]);

        $monthlyTotalsQuery = Overtime::with('user')
            ->whereBetween('date', [
                $periodStart->toDateString(),
                $periodEnd->toDateString(),
            ])
            ->where('status', 'accepted');

        if (Auth::user()->role !== 'admin') {
            $overtimeQuery->where('user_id', Auth::id());
            $monthlyTotalsQuery->where('user_id', Auth::id());
        }

        $overtime = $overtimeQuery
            ->orderByDesc('date')
            ->orderByDesc('created_at')
            ->get();

        $monthlyTotals = $monthlyTotalsQuery
            ->selectRaw('user_id, SUM(total_hours) as total')
            ->groupBy('user_id')
            ->get();

        $filename = 'overtime_' . $periodStart->format('Y_m_d') . '_to_' . $periodEnd->format('Y_m_d') . '.xlsx';

        return Excel::download(
            new OvertimeExport($overtime, $monthlyTotals, $periodStart, $periodEnd),
            $filename
        );
    }
}
